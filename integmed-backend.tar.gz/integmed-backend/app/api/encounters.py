"""Encounter API - exports encounter routes"""
from app.api.patients import encounters_router as router
