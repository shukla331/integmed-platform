"""Clinical API - exports clinical routes"""  
from app.api.patients import clinical_router as router
